import React from "react";

export default function Terminos() {
  return (
    <div className="max-w-6xl mx-auto px-4">
      <h2 className="text-2xl font-bold mb-4">Términos</h2>
      <p className="text-zinc-600">PlaceHolder</p>
    </div>
  );
}
