export default {
  plugins: {
    "@tailwindcss/postcss": {},  // <- plugin correcto para Tailwind v4
    autoprefixer: {},            // opcional pero recomendado
  },
};
